# Aman-Kumar-Knab-

1. **How long did you spend on the coding assignment? What would you add to your solution if you had**
**more time? If you didn't spend much time on the coding assignment then use this as an opportunity to**
**explain what you would add.**
--> I have spent around 8-9 hours to solve the this assignment. If I had more time, I would add some additional features - 
    - **Caching and Performance** : I would implement a caching mechanism to store the quotes in some cache or in local memory. This will reduce the 
    number of API call and will improve and optimize the API performance.
    - **Security/Authentication** : I would add some security checks like adding Authentication and Authorization to the API. Also I would like to add some rate limit to prevent api abusing.
    - **Add some UI** : I would like to also add some UI may be an angular or react app to display the data in UI.

2. **What was the most useful feature that was added to the latest version of your language of choice? Please include a snippet of code that shows how you've used it.**
--> There are multiplpe useful features that has been added to different new versions of C#. Like instead of using null comparision by using `x==null` or `x!=null` simpler to use `x is null` or `x is not null` which has been introduced in c# 9.0. Also, the use of Null forgiving operation '!', which has been introduced in c# 8.0. Also the use of global using directives which has been introduced in c# 10.

```bash
if (cryptoQuotationResult is null || cryptoQuotationResult.Data is null)
{
    _logger.Log(LogLevel.Warning, $"{nameof(cryptoQuotationResult)} - GetQuoteForCryptoAsync returns no data for currency {exchangeCurrencyCode}");
    continue;
}
```

```bash
return cryptoCurrencyCodesResponse!;
```

```bash
global using Xunit;
global using FluentAssertions;
```

3. ***How would you track down a performance issue in production? Have you ever had to do this?**
--> To identify a performance issue in production I would first analyse the logs to look for any abnormality, especially paying attentions to the log timings and other behavior. I would also examine the database queries if any that has been used in the code and will find the possibilities to optimize the query by using different methods. I will also do the entire code review to see if there is any unoptimised codes or any memory leaks. I wil also try to check the possibility of using cache to optimize the same. I will also check the production deployment instance to see the user loads and possibility of scalability. Also to check them I would perform load testing to the instance. If possible an use some profiling tools.
I have done couple of things in past in different projects to help optimising performance like optimizing database queries and way of handling data. Also, I have implemented caching and optimizing memory management with .Net. 

4. **What was the latest technical book you have read or tech conference you have been to? What did you learn?**
--> I use to read multiple articles from Medium and c-sharpcorner to get upto date with new features. I also do follow .net dev blog to get some updates. I have attended .net conference 2023 recently where I learnt new .Net 8 features and performance improvements in ASP.NET core. Also new c#12 features.

5. What do you think about this technical assessment?
--> I really liked the assessment as it helped to showcase the real time skills for the API development. It also helped in showcasing best practices and implementing new c# features. I enjoyed working on it and I learned from it.

6. Please, describe yourself using JSON.

```bash
{
  "name": "Aman Kumar",
  "contact": {
    "phone": "+31-0684515973",
    "email": "amanchoudhary.com@gmail.com"
  },
  "summary":["I am working as a Senior Software Engineer having a multi-faceted professional accustomed with proven skills; with 8+ years of experience in developing, building, and designing Enterprise solutions with expertise in different domains (IoT, Travel, Finance,Security, Healthcare, Insurance etc.); targeting challenging and rewarding opportunities in Software Development with an organization of high repute."],
  "skills": [
    "C#",
    ".Net / .Net Core",
    "Web API",
    "Microservices",
    "Azure",
    "IoT",
    "GraphQL",
    "Kafka and KSQLDb",
    "NoSQL",
    "Sql Server",
    "Azure Active Directory",
    "Azure PaaS",
    "React",
    "Design Patterns",
    "Domain Driven Design",
    "WCF"
  ],
  "languages": [
    "English",
    "Hindi"
  ],
  "experience": [
    {
      "role": "Senior Software Engineer",
      "company": "Independer, Netherlands",
      "duration": "01/2022-Current"
    },
    {
      "role": "Senior Software Engineer",
      "company": "Cornerstone OnDemand, India",
      "duration": "12/2020-09/2021"
    },
    {
      "role": "Senior Engineer",
      "company": "Allegion India PLC, India",
      "duration": "09/2021-01/2020"
    },
    {
      "role": "Senior Engineer / Cloud Developer",
      "company": "Resideo Homes",
      "duration": "12/2019-01/2019"
    },
    {
      "role": "Senior Engineer",
      "company": "Mindtree Ltd",
      "duration": "01/2019-10/2015"
    }
  ],
  "education": {
    "degree": "B.Tech Computer Science and Engineering",
    "institution": "Bengal College of Engineering and Technology",
    "location": "Durgapur, WB",
    "year": "2015"
  }
}

```
