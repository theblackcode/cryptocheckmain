﻿namespace CryptoQuote.Models
{
    public class HttpClientSetting
    {
        public const string ClientName = "CoinMarketClientApi";
    }
}