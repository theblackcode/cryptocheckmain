﻿using CryptoQuote.Models;
using Newtonsoft.Json;
using System.Net;

namespace CryptoQuote.API.Middlewares
{
    /// <summary>
    /// Global Exception handler which handles entire API level exceptions
    /// </summary>
    public class GlobalExceptionHandler
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionHandler> _logger;
        public GlobalExceptionHandler(RequestDelegate next, ILogger<GlobalExceptionHandler> logger)
        {
            _next = next;
            _logger = logger;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (HttpResponseException httpEx)
            {
                _logger.Log(LogLevel.Error, httpEx.Message, httpEx);
                await HandleExceptionAsync(context, httpEx, httpEx.StatusCode);
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, ex.Message, ex);
                await HandleExceptionAsync(context, ex, (int)HttpStatusCode.InternalServerError);
            }
        }


        private static Task HandleApiExceptionAsync(HttpContext context, Exception ex)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            var response = new CryptoQuoteApiResponse<CryptoQuoteApiError>
            {
                Status = HttpStatus.Error.ToString(),
                Data = new List<CryptoQuoteApiError>
                  {
                      new CryptoQuoteApiError
                      {
                          Message = "An error occurred while processing your request.",
                          Details = ex.Message
                      }
                  }
            };

            return context.Response.WriteAsync(JsonConvert.SerializeObject(response));
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception ex, int httpStatusCode)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = httpStatusCode;

            var response = new CryptoQuoteApiResponse<CryptoQuoteApiError>
            {
                Status = HttpStatus.Error.ToString(),
                Data = new List<CryptoQuoteApiError>
                  {
                      new CryptoQuoteApiError
                      {
                          Message = "An error occurred while processing your request.",
                          Details = ex.Message
                      }
                  }
            };

            return context.Response.WriteAsync(JsonConvert.SerializeObject(response));
        }
    }
}
