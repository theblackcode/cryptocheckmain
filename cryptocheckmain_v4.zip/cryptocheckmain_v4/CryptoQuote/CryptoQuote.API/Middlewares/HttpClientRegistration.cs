﻿using CryptoQuote.Models;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Extensions.Http;

namespace CryptoQuote.API.Middlewares
{
    /// <summary>
    /// Adding Http Client Registration.
    /// </summary>
    public static class HttpClientRegistration
    {
        public static IServiceCollection AddCryptoHttpClient(this IServiceCollection services)
        {

            services.AddHttpClient(HttpClientSetting.ClientName, (serviceProvider, httpClient) =>
            {
                var cryptoApiOptions = serviceProvider.GetRequiredService<IOptions<CryptoApiOptions>>().Value;
                _ = httpClient.BaseAddress = new Uri(cryptoApiOptions.BaseUrl);
                httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
                httpClient.DefaultRequestHeaders.Add("X-CMC_PRO_API_KEY", cryptoApiOptions.ApiKey);
            })
                .AddPolicyHandler(GetRetryPolicy())
                .AddPolicyHandler(GetCircuitBreakerPolicy());

            return services;
        }


        /// <summary>
        /// Retry policy which will retry the operation up to 4 times with an increasing delay between retries.
        /// </summary>
        /// <returns></returns>
        static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
        {
            return HttpPolicyExtensions
                .HandleTransientHttpError()
                .WaitAndRetryAsync(4, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
        }

        /// <summary>
        /// Apply Circuit Breaker Policy where it opens the circuit after 3 consecutive errors
        /// then wait for 30 seconds before allowing further attempts.
        /// </summary>
        /// <returns></returns>
        static IAsyncPolicy<HttpResponseMessage> GetCircuitBreakerPolicy()
        {
            return HttpPolicyExtensions
                .HandleTransientHttpError()
                .CircuitBreakerAsync(3, TimeSpan.FromSeconds(30));
        }
    }


}
