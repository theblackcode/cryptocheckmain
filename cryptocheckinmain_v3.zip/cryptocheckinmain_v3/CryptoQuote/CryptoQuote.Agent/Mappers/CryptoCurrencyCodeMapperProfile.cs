﻿using AutoMapper;
using CryptoQuote.Models;

namespace CryptoQuote.Agent.Mappers
{
    public class CryptoCurrencyCodeMapperProfile : Profile
    {
        public CryptoCurrencyCodeMapperProfile()
        {
            CreateMap<CryptoCurrency, CryptoCurrencySymbol>()
                .ForMember(d=>d.Symbol, o => o.MapFrom(s=>s.Symbol))
                .ForMember(d=>d.Name, o => o.MapFrom(s=>s.Name));
        }
    }
}
