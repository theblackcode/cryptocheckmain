﻿using AutoMapper;
using CryptoQuote.Agent;
using CryptoQuote.Contracts;
using CryptoQuote.Contracts.HttpConnector;
using CryptoQuote.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json.Linq;

namespace CryptoQuote.Tests
{
    public class CryptoQuoteAgentTests
    {
        private readonly Mock<IRestClient> _mockRestClient;
        private readonly Mock<ILogger<CryptoQuoteAgent>> _mockLogger;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<ICachingService> _mockCachingService;
        private readonly ICryptoQuoteAgent _cryptoQuoteAgent;
        public CryptoQuoteAgentTests()
        {
            _mockRestClient = new Mock<IRestClient>();
            _mockLogger = new Mock<ILogger<CryptoQuoteAgent>>();
            _mockMapper = new Mock<IMapper>();
            _mockCachingService = new Mock<ICachingService>();
            _cryptoQuoteAgent = new CryptoQuoteAgent(_mockRestClient.Object, _mockLogger.Object, _mockMapper.Object, _mockCachingService.Object);
        }


        #region Test for Constructor

        [Fact]
        public void Constructor_ShouldThrowArgumentNullException_WhenRestlientIsNull()
        {
            // Act
            Action act = () => new CryptoQuoteAgent(null, _mockLogger.Object, _mockMapper.Object, _mockCachingService.Object);

            // Assert
            act.Should().Throw<ArgumentNullException>().WithMessage("*restClient*");
        }

        [Fact]
        public void Constructor_ShouldThrowArgumentNullException_WhenLoggerIsNull()
        {
            // Act
            Action act = () => new CryptoQuoteAgent(_mockRestClient.Object, null, _mockMapper.Object, _mockCachingService.Object);

            // Assert
            act.Should().Throw<ArgumentNullException>().WithMessage("*logger*");
        }

        [Fact]
        public void Constructor_ShouldThrowArgumentNullException_WhenMapperIsNull()
        {
            // Act
            Action act = () => new CryptoQuoteAgent(_mockRestClient.Object, _mockLogger.Object, null, _mockCachingService.Object);

            // Assert
            act.Should().Throw<ArgumentNullException>().WithMessage("*mapper*");
        }

        [Fact]
        public void Constructor_ShouldThrowArgumentNullException_WhenCachingServiceIsNull()
        {
            // Act
            Action act = () => new CryptoQuoteAgent(_mockRestClient.Object, _mockLogger.Object, _mockMapper.Object, null);

            // Assert
            act.Should().Throw<ArgumentNullException>().WithMessage("*cachingService*");
        }
        #endregion

        #region Tests for GetCryptoCurrencyCodesAsync
        [Theory]
        [InlineData(100)]
        public async Task GetCryptoCurrencyCodesAsync_ShouldReturnMappedResult_WhenRestClientReturnsData(int limit)
        {
            // Arrange
            string warningMessage = $"getCryptoCurrencyResult - GetCryptoCurrencyCodesAsync returns no data.";
            var restClientResult = new CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>
            {
                Status = new CryptoApiStatus { },
                Data = new List<CryptoCurrency>
                {
                    new CryptoCurrency { Id = 1, Name = "Bitcoin", Symbol = "BTC" },
                    new CryptoCurrency { Id = 2, Name = "Ethereum", Symbol = "ETH" }
                }
            };
            var mappedResult = new List<CryptoCurrencySymbol>
            {
                new CryptoCurrencySymbol {Name = "Bitcoin", Symbol = "BTC" },
                new CryptoCurrencySymbol { Name = "Ethereum", Symbol = "ETH" }
            };
            _mockRestClient.Setup(x => x.GetCryptoCurrencyCodesAsync(limit)).ReturnsAsync(restClientResult);
            _mockMapper.Setup(x => x.Map<IEnumerable<CryptoCurrencySymbol>>(restClientResult.Data)).Returns(mappedResult);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>>>()))
                .ReturnsAsync(restClientResult);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoCurrencyCodesAsync(limit);

            // Assert
            result.Should().BeEquivalentTo(mappedResult);
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>>>()), Times.Once);
            _mockMapper.Verify(x => x.Map<IEnumerable<CryptoCurrencySymbol>>(restClientResult.Data), Times.Once);

            _mockLogger.Verify(x => x.Log(
       LogLevel.Warning,
        It.IsAny<EventId>(),
        It.Is<It.IsAnyType>((v, t) => v.ToString() == warningMessage),
        It.IsAny<Exception>(),
        (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()), Times.Never);


        }

        [Fact]
        public async Task GetCryptoCurrencyCodesAsync_ShouldReturnEmptyResult_WhenRestClientReturnsNull()
        {
            // Arrange
            int limit = 10;
            string warningMessage = $"cryptoCurrencyResult - GetCryptoCurrencyCodesAsync returns no data.";
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(),
               It.IsAny<Func<Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>>>()))
               .ReturnsAsync((CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>)null);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoCurrencyCodesAsync(limit);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(),
               It.IsAny<Func<Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>>>()), Times.Once);
            _mockMapper.Verify(x => x.Map<IEnumerable<CryptoCurrencySymbol>>(It.IsAny<IEnumerable<CryptoCurrency>>()), Times.Never);


            _mockLogger.Verify(x => x.Log(
      LogLevel.Warning,
       It.IsAny<EventId>(),
       It.Is<It.IsAnyType>((v, t) => v.ToString() == warningMessage),
       It.IsAny<Exception>(),
       (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()), Times.Once);

        }

        [Fact]
        public async Task GetCryptoCurrencyCodesAsync_ShouldReturnEmptyResult_WhenRestClientReturnsDataNull()
        {
            // Arrange
            int limit = 10;
            string warningMessage = $"cryptoCurrencyResult - GetCryptoCurrencyCodesAsync returns no data.";

            var restClientResult = new CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>
            {
                Status = new CryptoApiStatus { },
                Data = null
            };

            _mockRestClient.Setup(x => x.GetCryptoCurrencyCodesAsync(It.IsAny<int>())).ReturnsAsync(restClientResult);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(),
              It.IsAny<Func<Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>>>()))
              .ReturnsAsync(restClientResult);


            // Act
            var result = await _cryptoQuoteAgent.GetCryptoCurrencyCodesAsync(limit);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(),
              It.IsAny<Func<Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>>>()), Times.Once);
            _mockMapper.Verify(x => x.Map<IEnumerable<CryptoCurrencySymbol>>(It.IsAny<IEnumerable<CryptoCurrency>>()), Times.Never);

            _mockLogger.Verify(x => x.Log(
     LogLevel.Warning,
      It.IsAny<EventId>(),
      It.Is<It.IsAnyType>((v, t) => v.ToString() == warningMessage),
      It.IsAny<Exception>(),
      (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()), Times.Once);
        }
        #endregion


        #region Test for GetCryptoQuotationAsync
        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnQuotations_WhenRestClientReturnsData(string currencyCode)
        {
            // Arrange
            string warningMessage = $"cryptoQuotationResult - GetQuoteForCryptoAsync returns no data.";
            var restClientResultForUSD = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["USD"] = new JObject
                            {
                                ["price"] = 50000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForEUR = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["EUR"] = new JObject
                            {
                                ["price"] = 42000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForBRL = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["BRL"] = new JObject
                            {
                                ["price"] = 270000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForGBP = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["GBP"] = new JObject
                            {
                                ["price"] = 36000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForAUD = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["AUD"] = new JObject
                            {
                                ["price"] = 65000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };

            var expectedQuotations = new List<CryptoCurrencyQuotation>
                    {
                        new CryptoCurrencyQuotation { Currency = "USD", Price = 50000.0 },
                        new CryptoCurrencyQuotation { Currency = "EUR", Price = 42000.0 },
                        new CryptoCurrencyQuotation { Currency = "BRL", Price = 270000.0 },
                        new CryptoCurrencyQuotation { Currency = "GBP", Price = 36000.0 },
                        new CryptoCurrencyQuotation { Currency = "AUD", Price = 65000.0 }
                    };

            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_USD"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForUSD);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_EUR"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForEUR);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_BRL"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForBRL);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_GBP"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForGBP);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_AUD"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForAUD);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEquivalentTo(expectedQuotations);
            _mockCachingService.Verify((x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())), Times.Exactly(5));
            _mockLogger.Verify(x => x.Log(
    LogLevel.Warning,
     It.IsAny<EventId>(),
     It.Is<It.IsAnyType>((v, t) => v.ToString() == warningMessage),
     It.IsAny<Exception>(),
     (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()), Times.Never);
        }


        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnEmptyResult_WhenRestClientReturnsNull(string currencyCode)
        {
            // Arrange
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()))
                .ReturnsAsync((CoinMarketCryptoApiResponse<JObject>)null);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify((x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())), Times.Exactly(5));

            VerifyLoggerWarningWhenNoData("cryptoQuotationResult - GetQuoteForCryptoAsync returns no data for currency");

        }


        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnEmptyResult_WhenRestClientReturnsDataNull(string currencyCode)
        {
            // Arrange

            var restClientResult = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = null
            };
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
               It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()))
               .ReturnsAsync(restClientResult);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
               It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()), Times.Exactly(5));
            VerifyLoggerWarningWhenNoData("cryptoQuotationResult - GetQuoteForCryptoAsync returns no data for currency");
        }

        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnEmptyResult_WhenRestClientReturnsDataCurrencyCodeNull(string currencyCode)
        {
            // Arrange

            var restClientResult = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject { }
            };

            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
              It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()))
              .ReturnsAsync(restClientResult);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()), Times.Exactly(5));

            VerifyLoggerWarningWhenNoData("cryptoData has no data for currency");
        }

        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnEmptyResult_WhenRestClientReturnsDataCurrencyCodeQuoteNull(string currencyCode)
        {
            // Arrange

            var restClientResult = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject { }

                }
            };
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
             It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()))
             .ReturnsAsync(restClientResult);

            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()), Times.Exactly(5));

            VerifyLoggerWarningWhenNoData("quote has no data for currency");
        }

        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnEmptyResult_WhenRestClientReturnsDataCurrencyCodeQuotationDetailsNull(string currencyCode)
        {
            // Arrange

            var restClientResult = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject { }
                    }
                }
            };
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
            It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()))
            .ReturnsAsync(restClientResult);


            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEmpty();
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
                 It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()), Times.Exactly(5));

            VerifyLoggerWarningWhenNoData("quotationDetails has no data for currency");
        }


        [Theory]
        [InlineData("BTC")]
        public async Task GetCryptoQuotationAsync_ShouldReturnEmptyResult_WhenRestClientReturnsInvalidData(string currencyCode)
        {
            // Arrange
            string warningMessage = $"cryptoQuotationResult - GetQuoteForCryptoAsync returns no data.";
            var restClientResultForUSD = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["USD"] = new JObject
                            {
                                ["price"] = "invalid",
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForEUR = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["EUR"] = new JObject
                            {
                                ["price"] = null,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForBRL = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["BRL"] = new JObject
                            {
                                ["price"] = 270000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForGBP = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["GBP"] = new JObject
                            {
                                ["price"] = 36000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };
            var restClientResultForAUD = new CoinMarketCryptoApiResponse<JObject>
            {
                Data = new JObject
                {
                    [currencyCode] = new JObject
                    {
                        ["quote"] = new JObject
                        {
                            ["AUD"] = new JObject
                            {
                                ["price"] = 65000.0,
                                ["lastUpdated"] = DateTime.Now
                            }

                        }
                    }
                }
            };

            var expectedQuotations = new List<CryptoCurrencyQuotation>
                    {
                        new CryptoCurrencyQuotation { Currency = "USD", Price = 0 },
                        new CryptoCurrencyQuotation { Currency = "EUR", Price = 0 },
                        new CryptoCurrencyQuotation { Currency = "BRL", Price = 270000.0 },
                        new CryptoCurrencyQuotation { Currency = "GBP", Price = 36000.0 },
                        new CryptoCurrencyQuotation { Currency = "AUD", Price = 65000.0 }
                    };

            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_USD"),
               It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForUSD);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_EUR"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForEUR);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_BRL"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForBRL);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_GBP"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForGBP);
            _mockCachingService.Setup(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.Is<string>(s => s == $"{currencyCode}_AUD"),
                It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>())).ReturnsAsync(restClientResultForAUD);


            // Act
            var result = await _cryptoQuoteAgent.GetCryptoQuotationAsync(currencyCode);

            // Assert
            result.Should().BeEquivalentTo(expectedQuotations);
            _mockCachingService.Verify(x => x.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(It.IsAny<string>(),
               It.IsAny<Func<Task<CoinMarketCryptoApiResponse<JObject>>>>()), Times.Exactly(5));
            _mockLogger.Verify(x => x.Log(
    LogLevel.Warning,
     It.IsAny<EventId>(),
     It.Is<It.IsAnyType>((v, t) => v.ToString() == warningMessage),
     It.IsAny<Exception>(),
     (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()), Times.Never);
        }


        #endregion


        #region Private Method
        private void VerifyLoggerWarningWhenNoData(string initialMessage)
        {
            List<string> currencies = new List<string>() { "USD", "EUR", "BRL", "GBP", "AUD" };
            foreach (var currency in currencies)
            {
                var warningMessage = $"{initialMessage} {currency}";
                _mockLogger.Verify(x => x.Log(
    LogLevel.Warning,
     It.IsAny<EventId>(),
     It.Is<It.IsAnyType>((v, t) => v.ToString() == warningMessage),
     It.IsAny<Exception>(),
     (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()), Times.Exactly(1));
            }
        }
        #endregion
    }
}
