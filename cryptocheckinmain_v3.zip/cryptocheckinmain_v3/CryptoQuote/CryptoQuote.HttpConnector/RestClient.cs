﻿using CryptoQuote.Contracts.HttpConnector;
using CryptoQuote.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;

namespace CryptoQuote.HttpConnector
{
    public class RestClient : IRestClient
    {
        private readonly IHttpClientProvider _httpClientProvider;
        private readonly CryptoApiOptions _cryptoApiOptions;
        private readonly ILogger<RestClient> _logger;

        public RestClient(IHttpClientProvider httpClientProvider, IOptions<CryptoApiOptions> options, ILogger<RestClient> logger)
        {
            _cryptoApiOptions = options?.Value ?? throw new ArgumentNullException(nameof(options));
            _httpClientProvider = httpClientProvider ?? throw new ArgumentNullException(nameof(httpClientProvider));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        ///<inheritdoc/>
        public async Task<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>> GetCryptoCurrencyCodesAsync(int limit)
        {
            if (limit <= 0)
            {
                _logger.Log(LogLevel.Error, $"limit = {limit} is less than or equal to 0.");
                throw new ArgumentException($"limit must be greater than or equal to 1");
            }

            CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>> cryptoCurrencyCodesResponse = null;
            string uri = $"{_cryptoApiOptions.GetCurrencyCodeUri}?limit={limit}";
            _logger.Log(LogLevel.Information, $"Calling api with uri - {uri}.");
            var httpResponseMessage = await SendRequest(Method.GET, uri);
            if (httpResponseMessage is not null && httpResponseMessage.StatusCode is HttpStatusCode.OK)
            {
                var httpResponseContent = await httpResponseMessage.Content.ReadAsStringAsync();
                if (httpResponseContent is null)
                    return cryptoCurrencyCodesResponse!;

                cryptoCurrencyCodesResponse = JsonConvert.DeserializeObject<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(httpResponseContent)!;
            }

            return cryptoCurrencyCodesResponse!;
        }

        ///<inheritdoc/>
        public async Task<CoinMarketCryptoApiResponse<JObject>> GetQuoteForCryptoAsync(string cryptoCode, string convertCurrencyCode)
        {
            if (string.IsNullOrEmpty(cryptoCode)) throw new ArgumentNullException(nameof(cryptoCode));
            if (string.IsNullOrEmpty(convertCurrencyCode)) throw new ArgumentNullException(nameof(convertCurrencyCode));
            CoinMarketCryptoApiResponse<JObject> cryptoCurrencyQuoationApiResponse = null;
            string uri = $"{_cryptoApiOptions.GetExchangeUri}?symbol={cryptoCode}&convert={convertCurrencyCode}";
            _logger.Log(LogLevel.Information, $"Calling api with uri - {uri}.");
            var httpResponseMessage = await SendRequest(Method.GET, uri);
            if (httpResponseMessage is not null && httpResponseMessage.StatusCode is HttpStatusCode.OK)
            {
                var httpResponseContent = await httpResponseMessage.Content.ReadAsStringAsync();
                if (httpResponseContent is null)
                    return cryptoCurrencyQuoationApiResponse!;

                cryptoCurrencyQuoationApiResponse = JsonConvert.DeserializeObject<CoinMarketCryptoApiResponse<JObject>>(httpResponseContent)!;
            }

            return cryptoCurrencyQuoationApiResponse!;

        }


        #region Private Methods
        private async Task<HttpResponseMessage> SendRequest(Method method, string uri)
        {
            if (string.IsNullOrEmpty(uri))
            {
                throw new ArgumentException($"uri can not be null or empty");
            }

            HttpResponseMessage response = null;

            try
            {
                switch (method)
                {
                    case Method.GET:
                        response = await _httpClientProvider.GetJsonAsync(uri);
                        break;
                    default:
                        response = new HttpResponseMessage()
                        {
                            StatusCode = HttpStatusCode.MethodNotAllowed,
                        };
                        break;
                }
            }
            catch (Exception ex)
            {

                response = new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.InternalServerError,
                    Content = new StringContent(ex.Message)
                };
            }
            return response;

        }

        #endregion
    }
}