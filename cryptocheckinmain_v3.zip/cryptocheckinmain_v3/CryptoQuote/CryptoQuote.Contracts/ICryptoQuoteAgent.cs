﻿using CryptoQuote.Models;

namespace CryptoQuote.Contracts
{
    public interface ICryptoQuoteAgent
    {
        /// <summary>
        /// Gets list of Crypto currency symbols.
        /// </summary>
        /// <returns>List of currency symbols.</returns>
        Task<IEnumerable<CryptoCurrencySymbol>> GetCryptoCurrencyCodesAsync(int limit);

        /// <summary>
        /// Get list of Crypto Currency Quotations.
        /// </summary>
        /// <param name="currencyCode">Currency Code e.g, BTC etc</param>
        /// <returns>List of Crypto currency quotations.</returns>
        Task<IEnumerable<CryptoCurrencyQuotation>> GetCryptoQuotationAsync(string currencyCode);
    }
}
