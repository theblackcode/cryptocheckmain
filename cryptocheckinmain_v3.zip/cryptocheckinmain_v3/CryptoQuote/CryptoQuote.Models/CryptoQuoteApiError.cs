﻿namespace CryptoQuote.Models
{
    /// <summary>
    /// Display error at Cryptoquote API level 
    /// </summary>
    public class CryptoQuoteApiError
    {
        /// <summary>
        /// Error Messsage
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Error Details
        /// </summary>
        public string Details { get; set; }
    }
}
