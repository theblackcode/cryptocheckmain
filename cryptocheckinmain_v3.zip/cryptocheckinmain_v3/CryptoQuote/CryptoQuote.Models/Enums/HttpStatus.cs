﻿namespace CryptoQuote.Models
{
    public enum HttpStatus
    {
        Error,
        Success,
    }
}
