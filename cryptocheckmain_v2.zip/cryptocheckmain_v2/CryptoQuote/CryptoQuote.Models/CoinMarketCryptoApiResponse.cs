﻿using Newtonsoft.Json;

namespace CryptoQuote.Models
{
    public class CoinMarketCryptoApiResponse<T>
    {
        [JsonProperty("status")]
        public CryptoApiStatus Status { get; set; }

        [JsonProperty("data")]
        public T Data { get; set; }
    }
}
