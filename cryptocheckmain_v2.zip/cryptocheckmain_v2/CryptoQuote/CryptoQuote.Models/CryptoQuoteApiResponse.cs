﻿namespace CryptoQuote.Models
{
    /// <summary>
    /// Crypto Quote Api response to return response which contains Status - Error or Success and the list of data
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CryptoQuoteApiResponse<T>
    {
        /// <summary>
        /// Status of Api - Success or Error
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// List of Data
        /// </summary>
        public IEnumerable<T> Data { get; set; }
    }
}
