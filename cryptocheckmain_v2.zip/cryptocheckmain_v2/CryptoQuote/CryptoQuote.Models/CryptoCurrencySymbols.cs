﻿namespace CryptoQuote.Models
{
    /// <summary>
    /// Get Crypto Currency Code response with Code and name
    /// </summary>
    public class CryptoCurrencySymbol
    {
        /// <summary>
        /// Crypto Code
        /// </summary>
        public string Symbol { get; set; }

        /// <summary>
        /// Name of the Crypto currency
        /// </summary>
        public string Name { get; set; }
    }
}
