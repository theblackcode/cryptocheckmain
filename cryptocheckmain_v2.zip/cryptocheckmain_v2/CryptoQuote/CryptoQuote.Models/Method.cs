﻿namespace CryptoQuote.Models
{
    public enum Method
    {
        GET,
        POST
    }
}
