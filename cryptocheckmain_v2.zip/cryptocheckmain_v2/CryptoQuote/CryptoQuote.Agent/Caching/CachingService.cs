﻿using CryptoQuote.Contracts;
using CryptoQuote.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CryptoQuote.Agent.Caching
{
    public class CachingService : ICachingService
    {
        private readonly IMemoryCache _memoryCache;
        private readonly CacheOptions _cacheOptions;
        private readonly int _expirationTime;
        public CachingService(IMemoryCache memoryCache, IOptions<CacheOptions> options)
        {
            _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(memoryCache));
            _cacheOptions = options?.Value ?? throw new ArgumentNullException(nameof(options));
            int.TryParse(_cacheOptions.ExpirationTimeInMinute.ToString(), out _expirationTime);
        }

        ///<inheritdoc/>
        public async Task<T> GetOrSetAsync<T>(string key, Func<Task<T>> getData)
        {

            string cachingKey = $"{_cacheOptions.BaseKey}_{key}";
            // Trying to get data from the cache.
            if (!_memoryCache.TryGetValue(cachingKey, out Lazy<Task<T>> lazyData))
            {
                // If the cache is empty, create a new Lazy object to load the data from the getData function
                lazyData = new Lazy<Task<T>>(async () => await getData());

                // Set the cache options
                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(_expirationTime > 0 ? TimeSpan.FromMinutes(_expirationTime) : TimeSpan.FromMinutes(10)); // Set the expiration time

                // Set the data to the cache
                _memoryCache.Set(cachingKey, lazyData, cacheOptions);
            }

            // Return the data from the Lazy object
            return await lazyData.Value;
        }
    }
}
