﻿using AutoMapper;
using CryptoQuote.Contracts;
using CryptoQuote.Contracts.HttpConnector;
using CryptoQuote.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace CryptoQuote.Agent
{
    public class CryptoQuoteAgent : ICryptoQuoteAgent
    {
        private readonly IRestClient _restClient;
        private readonly ILogger<CryptoQuoteAgent> _logger;
        private readonly IMapper _mapper;
        private readonly ICachingService _cachingService;
        public CryptoQuoteAgent(IRestClient restClient, ILogger<CryptoQuoteAgent> logger, IMapper mapper, ICachingService cachingService)
        {
            _restClient = restClient ?? throw new ArgumentNullException(nameof(restClient));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _cachingService = cachingService ?? throw new ArgumentNullException(nameof(cachingService));

        }

        ///<inheritdoc/>
        public async Task<IEnumerable<CryptoCurrencySymbol>> GetCryptoCurrencyCodesAsync(int limit)
        {
            //TODO: restructure the key
            var cryptoCurrencyResult = await _cachingService.GetOrSetAsync<CoinMarketCryptoApiResponse<IEnumerable<CryptoCurrency>>>(limit.ToString(), () => _restClient.GetCryptoCurrencyCodesAsync(limit));
            if (cryptoCurrencyResult is null || cryptoCurrencyResult.Data is null)
            {
                _logger.Log(LogLevel.Warning, $"{nameof(cryptoCurrencyResult)} - GetCryptoCurrencyCodesAsync returns no data.");
                return Enumerable.Empty<CryptoCurrencySymbol>();
            }

            return _mapper.Map<IEnumerable<CryptoCurrencySymbol>>(cryptoCurrencyResult.Data);

        }

        ///<inheritdoc/>
        public async Task<IEnumerable<CryptoCurrencyQuotation>> GetCryptoQuotationAsync(string currencyCode)
        {
            var exchangeCurrencyCodes = new List<string> { "USD", "EUR", "BRL", "GBP", "AUD" };
            var cryptoCurrencies = new List<CryptoCurrencyQuotation>();
            string keyTemplate = $"{currencyCode}_{{0}}";

            // Since the api subscription is in free plan,
            // so it has limitation for only displaying one currency code at a time.
            // That's why for now calling it one at a time,
            // for paid subscription only once it has to be called with all exchangecurrency codes together like USD, EUR, BRL, FBP, AUD
            foreach (var exchangeCurrencyCode in exchangeCurrencyCodes)
            {
                string key = string.Format(keyTemplate, exchangeCurrencyCode);

                //Get Currency conversion data from cache first if not then make a call to the endpoint
                var cryptoQuotationResult = await _cachingService.GetOrSetAsync<CoinMarketCryptoApiResponse<JObject>>(key, () => _restClient.GetQuoteForCryptoAsync(currencyCode, exchangeCurrencyCode));
                if (cryptoQuotationResult?.Data is null)
                {
                    _logger.Log(LogLevel.Warning, $"{nameof(cryptoQuotationResult)} - GetQuoteForCryptoAsync returns no data for currency {exchangeCurrencyCode}");
                    continue;
                }

                // Use pattern matching to cast and check for null in one statement
                if (cryptoQuotationResult.Data[currencyCode] is not JObject cryptoData)
                {
                    _logger.LogWarning($"{nameof(cryptoData)} has no data for currency {exchangeCurrencyCode}");
                    continue;
                }
                if (cryptoData["quote"] is not JObject quote)
                {
                    _logger.LogWarning($"{nameof(quote)} has no data for currency {exchangeCurrencyCode}");
                    continue;
                }
                if (quote[exchangeCurrencyCode] is not JObject quotationDetails)
                {
                    _logger.LogWarning($"{nameof(quotationDetails)} has no data for currency {exchangeCurrencyCode}");
                    continue;
                }

                var cryptoCurrencyQuotation = new CryptoCurrencyQuotation
                {
                    Currency = exchangeCurrencyCode,
                    Price = double.TryParse(quotationDetails["price"]?.ToString(), out var price) ? price : 0
                };

                cryptoCurrencies.Add(cryptoCurrencyQuotation);
            }
            return cryptoCurrencies;
        }
    }
}